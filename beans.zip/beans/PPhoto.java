package com.cg.capbook.beans;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class PPhoto {
	@Id
	private String userName;
	private String imageURL;
	private File photoFile;
	@ManyToOne
	UserAccount userAccount;
	
	@OneToMany(mappedBy="pPhoto")
	private List<PLike> pLike;
	
	@OneToMany(mappedBy="pPhoto")
	private List<PComment> pComment;
	
	@OneToMany(mappedBy="pPhoto")
	private List<PTag> pTag;

	public PPhoto() {
		super();
		// TODO Auto-generated constructor stub
	}
}
