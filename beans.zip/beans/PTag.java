package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class PTag {
	@Id
	String username;
	@ManyToOne
	PPhoto pPhoto;
	
	@ManyToOne
	PStatus pStatus;
	public PTag() {
		super();
	}


	public PTag(String username, PPhoto photo, PStatus status) {
		super();
		this.username = username;
		this.pPhoto = photo;
		this.pStatus = status;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PTag other = (PTag) obj;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Tag [username=" + username + "]";
	}
	
}
