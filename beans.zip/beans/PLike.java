package com.cg.capbook.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class PLike {
	@Id
	String username;
	@ManyToOne
	PPhoto pPhoto;
	
	@ManyToOne
	PStatus pStatus;

	public PLike() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PLike(String username, PPhoto photo, PStatus status) {
		super();
		this.username = username;
		this.pPhoto = photo;
		this.pStatus = status;
	}
	
}
