package com.cg.capbook.beans;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class PStatus {
	@Id
	String username;
	String status;
	@ManyToOne
	 UserAccount userAccount;
	
	@OneToMany(mappedBy="pStatus")
	private List<PLike> pLike;
	
	@OneToMany(mappedBy="pStatus")
	private List<PComment> pComment;
	
	@OneToMany(mappedBy="pStatus")
	private List<PTag> pTag;
	
	public PStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

}
