package com.cg.capbook.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class PComment {
	@Id
	String username;
	String pcomment;
	@ManyToOne
	PPhoto pPhoto;
	
	@ManyToOne
	PStatus pStatus;

	public PComment(String username, String comment, PPhoto photo, PStatus status) {
		super();
		this.username = username;
		this.pcomment = comment;
		this.pPhoto = photo;
		this.pStatus = status;
	}

	public PComment() {
		super();
	}
	
	
}
